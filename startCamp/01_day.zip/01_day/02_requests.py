import requests
import bs4

url = 'https://finance.naver.com/sise/'

response = requests.get(url)

html = response.text

soup = bs4.BeautifulSoup(html, 'html.parser')   #파싱하기위한 코드
kospi = soup.select_one('#KOSPI_now').text  #아이디값으로 접근해서 text를 꺼내오라는 명령


print(kospi)