import webbrowser

idols = ['iu','ziont','bts']

for idol in idols:
    webbrowser.open(f'http://www.google.com/search?q={idol}')
